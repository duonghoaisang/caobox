// JavaScript Document
(function($){
	$.fn.validate = function(opt){
		var cfg = {
			required: [],
			disabled: false,
			lang: 'vn'
		}
		if(opt)$.extend(cfg,opt);
		var required = {};
		for(var i in cfg.required){ required[cfg.required[i]+'['+cfg.lang+']'] = true;required[cfg.required[i]] = true;}
		var obj  = this; 
		$(this).submit(function(){
			if(cfg.disabled){
				alert(cfg.disabled);
				return false;
			}
			var r = true;
			$(obj).find('input,textarea,select').each(function(){
				if(required[this.name]===true && this.value == ''){
					alert(this.title?this.title:'Please input '+this.name.toUpperCase()); $(this).focus(); r = false;return false;
				}
			});
			return r;
		});
	}  
})(jQuery)