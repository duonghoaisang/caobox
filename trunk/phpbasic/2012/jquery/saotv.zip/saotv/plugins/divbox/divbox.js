/*
	DivBox gallery
	@copyright: http://wwww.phpbasic.com
	@Contact: w2ajax@gmail.com for lastest version.
*/
(function($){
	$.fn.divbox = function(opt){
		var _cfg = {
			source: '<div id="divbox_frame"><div class="closed"></div><div id="divbox_content"></div></div>',
			width: null, 
			height: null,
			scrollbar: 'auto',
			isGallery: false,
			ajax: false,
			clone: null,// element want to clone
			closed: '#divbox_frame .closed',
			prev: '#divbox_frame .prev',
			next: '#divbox_frame .next',
			path: 'players/'
			
		}
		if(opt)$.extend(_cfg,opt);
		$(this).bind('click',function(){
			$('body').prepend('<div id="divbox"></div>'+_cfg.source);
			var requires  = '#divbox,#divbox_frame,#divbox_content';
			var len = $(requires).length;
			if(len < 3){
				$(requires).remove();
				alert('Wrong defined HTML source (_cfg.source)'); 
				return false;
			}
			$(_cfg.closed).hide();
			

			this.closed = function(){
				$('#divbox_frame').animate({
					top: format['top'], 
					left: format['left'],
					width: '0px',
					height: '0px'
				},500,function(){
					$(this).remove();
					$('#divbox').remove();
					$('object,embed,select').show();
				});
			}
			this.animate = function(t,l,w,h,fn){
				$('#divbox_frame').animate({left: l,width: w}).animate({top: t,height: h},500,function(){
					if(typeof(fn) == 'function') fn($('#divbox_content'));
					//$(this).animate({height: h + 40});
					$(_cfg.closed).show().click(function(){obj.closed();});
				})
			}
			this.flashEmbedString = function(file,w,h,type){ // default type is FLV
				var flashvar = '';
				if(type=='mp3') flashvar = '&provider=sound';
				var str = '<object id="player" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" name="player" width="'+w+'" height="'+h+'">';
				str += '<param name="movie" value="'+_cfg.path+'player-viral.swf" />';
				str += '<param name="allowfullscreen" value="true" />';
				str += '<param name="flashvars" value="file='+file+'&autostart=true'+flashvar+'" />';
				str += '<embed';
					str += ' type="application/x-shockwave-flash"';
					str += ' id="player2"';
					str += ' name="player2"';
					str += ' src="'+_cfg.path+'player-viral.swf" ';
					str += ' width="'+w+'" ';
					str += ' height="'+h+'"';
					str += ' allowfullscreen="true"';
					str += ' flashvars="file='+file+'&start=true&autostart=true'+flashvar+'" ';
				str += ' />';
				str += '</object>';
				return str;
				
			}
			this.viewImage = function(){
				$('#divbox_content').html('<img src="'+obj.href+'" />').find('img').hide();
				var Img = new Image();
				Img.onload = function(){
					$('#divbox_content img').attr('src',obj.href);
					var top = sizesystem[3] + Math.round((sizesystem[5] - Img.height)/2);
					var left = Math.round((sizesystem[0] - Img.width)/2);
					var width = _cfg.width?_cfg.width:Img.width;
					var height = _cfg.height?_cfg.height:Img.height;
					obj.animate(top,left,width,height,function(o){
						$('#divbox_content img').fadeIn();	
					})
					//IE 
					Img.onload=function(){};
				}
				Img.src = obj.href;
			}
			
			this.viewDefault = function(){
				var winW = _cfg.width?_cfg.width:sizesystem[0]-100;
				var winH = _cfg.height?_cfg.height:sizesystem[5]-100;
				var top = sizesystem[3] + Math.round((sizesystem[5] - winH)/2);
				var left = Math.round((sizesystem[0] - winW)/2);
				obj.animate(top,left,winW,winH,function(o){
					$(o).html('<iframe src="'+obj.href+'" width="'+(winW-12)+'" frameborder="0" scrolling="'+_cfg.scrollbar+'" height="'+winH+'"></iframe>');	
				});
			}
			this.viewFLV = function(){
				var winW = _cfg.width?_cfg.width:400;
				var winH = _cfg.height?_cfg.height:300;
				var top = sizesystem[3] + Math.round((sizesystem[5] - winH)/2);
				var left = Math.round((sizesystem[0] - winW)/2);
				var str = obj.flashEmbedString(obj.href,winW,winH,'flv');
				obj.animate(top,left,winW,winH,function(o){
					$(o).html(str);
				});
			}
			this.viewWMV = function(){
				var winW = _cfg.width?_cfg.width:400;
				var winH = _cfg.height?_cfg.height:300;
				var top = sizesystem[3] + Math.round((sizesystem[5] - winH)/2);
				var left = Math.round((sizesystem[0] - winW)/2);
				var str = '<object  type="application/x-oleobject" classid="CLSID:22D6f312-B0F6-11D0-94AB-0080C74C7E95" codebase="http://activex.microsoft.com/activex/controls/mplayer/en/nsmp2inf.cab#Version=6,4,7,1112"';
				str += ' width="'+winW+'" height="'+winH+'">';
				str += '<param name="filename" value="'+obj.href+'" />';
				str += '<param name="Showcontrols" value="true" />';
				str += '<param name="autoStart" value="true" />';
				str += '<embed type="application/x-mplayer2" src="'+obj.href+'" Showcontrols="true" autoStart="true" width="'+winW+'" height="'+winH+'"></embed>';
				str += '<object/>';
				obj.animate(top,left,winW,winH,function(o){
					$(o).html(str);
				});
			}
			this.viewMP3 = function(){
				var winW = 320;
				var winH = 80;
				var top = sizesystem[3] + Math.round((sizesystem[5] - winH)/2);
				var left = Math.round((sizesystem[0] - winW)/2);
				var str = obj.flashEmbedString(obj.href,winW,winH,'mp3');
				obj.animate(top,left,winW,winH,function(o){
					$(o).html(str);
				});
			}
			this.viewSWF = function(){
				var winW = _cfg.width?_cfg.width:400;
				var winH = _cfg.height?_cfg.height:300;
				var top = sizesystem[3] + Math.round((sizesystem[5] - winH)/2);
				var left = Math.round((sizesystem[0] - winW)/2);
				var str = obj.flashEmbedString(obj.href,winW,winH);
				obj.animate(top,left,winW,winH,function(o){
					$(o).html(str);
				});
			}
			
			var obj = this;
			var sizesystem = pageSize();
			var _click = $(obj).offset();
			$('object,embed,select').hide();
			var format = {
				'position':'absolute',
				'top': _click.top,
				'left': _click.left,
				'zIndex':'10002',
				'width': 0,
				'height': 0
			}

			$('#divbox').css({
				'width': '100%',//sizesystem[0]+'px',
				'height': sizesystem[1]+'px',
				'position':'absolute',
				'zIndex':'10001',
				'left':'0',
				'top':'0'
			}).click(function(){
				obj.closed();
			});
			$('#divbox_frame').css(format).animate({
				width: 50, 
				height: 50,
				top:sizesystem[3] + Math.round((sizesystem[5] - $(this).height())/2),
				left: Math.round((sizesystem[0] - $(this).width())/2) 
			});
			
			
			var aExt = obj.href.split('.');
			var ext = aExt[aExt.length-1];
			var str = '';
			switch(ext.toLowerCase()){
				case 'jpg':
				case 'jpeg':
				case 'gif':
				case 'png': this.viewImage();break;
				case 'flv':this.viewFLV();break;
				case 'wmv': this.viewWMV();break;
				case 'mp3': this.viewMP3();break;
				case 'swf': this.viewSWF();break;
				default: this.viewDefault();break;
			}
			
			
			return false;
		});
	}
	function pageSize(){
		var de = document.documentElement;
		var winW = window.innerWidth || self.innerWidth || (de&&de.clientWidth) || document.body.clientWidth;
		var winH = window.innerHeight || self.innerHeight || (de&&de.clientHeight) || document.body.clientHeight;
		var x = window.pageXOffset || self.pageXOffset || (de&&de.scrollLeft) || document.body.scrollLeft;
		var y = window.pageYOffset || self.pageYOffset || (de&&de.scrollTop) || document.body.scrollTop;
		var pW = window.innerWidth || document.body.scrollWidth || document.body.offsetWidth;
		var pH = window.innerHeight+window.scrollMaxY || document.body.scrollHeight || document.body.offsetHeight;
		var w = pW<winW?pW:winW; //18 = the width of window scrollbar 
		var h = pH<=winH?winH:pH+20;
		arrayPageSize = [w,h,x,y,winW,winH];
		return arrayPageSize;
	}
})(jQuery)