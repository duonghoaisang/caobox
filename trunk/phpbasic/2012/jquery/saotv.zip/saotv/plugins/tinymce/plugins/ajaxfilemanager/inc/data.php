<pre>Array
(
    [currentFolderPath] => D:/server/fw/v02/data/upload/
    [new_folder] => FD
)
</pre>

15/Oct/2010 23:11:01