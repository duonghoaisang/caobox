<?php
error_reporting(E_ALL & ~E_WARNING & ~E_NOTICE);
define('_ROOT',rtrim(dirname(__FILE__),'/').'/',true);
define('APPLICATION','',true);
define('_CORE',rtrim(dirname(__FILE__),'/').'/',true);
include _ROOT.'bootstrap.php';
/* Controller($rewrite, $htaccess, $multi_lang, $sef) */
$controller = new Controller(true,true,false,true);
$system = $controller;
require(_ROOT.'modules/global/hooks.php');
$hook = new bHooker;

if(!file_exists(_ROOT."modules/global/index.php")) $system->getError("Module GLOBAL doesn't exists");
if(!file_exists(_ROOT."modules/".$system->module.'/index.php')) $system->module = '404';
$hook->web_header();
require(_ROOT.'config.php');
require(_ROOT.'defined.php');
if(isset($cfg['lang'])) $system->lang = $cfg['lang'];
if($system->lang) require _ROOT.APPLICATION."/languages/".$system->lang.'/index.php';

$cache_dao = _CACHE.APPLICATION.'dao.php';
if(!file_exists($cache_dao)){
	$file_str = '<?php'."\n";
	$dir = dir(_ROOT.APPLICATION."/dao/");
	while ($file = $dir->read()) {
	  if (substr($file, -4) == '.php') {
		$class = ucfirst(substr($file,0,-4));
		$class_dao = $class.'DAO';
		require _ROOT.APPLICATION.'/dao/'.$file;
		$file_str .= 'require \''._ROOT.APPLICATION."/dao/".$file."';\n";
		if(class_exists($class_dao)){
			${'o'.$class} = new $class_dao;
			$file_str .= '$o'.$class.' = new '.$class_dao.";\n";
		}
	  }
	}
	$file_str .= '?>';
	$fp = @fopen($cache_dao,'w');
	if($fp) fwrite($fp,$file_str);
	fclose($fp);
}else{
	include $cache_dao;
}

/** PHPBB Forum**/
define('IN_PHPBB', true);
$phpbb_root_path = './forum/';
$phpEx = substr(strrchr(__FILE__, '.'), 1);
require($phpbb_root_path . 'common.' . $phpEx);
require($phpbb_root_path . 'includes/functions_user.' . $phpEx);
require($phpbb_root_path . 'includes/functions_module.' . $phpEx);
// Basic parameter data
$id 	= request_var('i', '');
$mode	= request_var('mode', '');

if ($mode == 'login' || $mode == 'logout' || $mode == 'confirm')
{
	define('IN_LOGIN', true);
}

// Start session management
$user->session_begin();
$auth->acl($user->data);
$user->setup('ucp');

// Setting a variable to let the style designer know where he is...
$template->assign_var('S_IN_UCP', true);

$module = new p_master();
$default = false;

/* End */
if(file_exists(_ROOT.APPLICATION."/modules/global/functions.php")) require(_ROOT.APPLICATION."/modules/global/functions.php");
require _ROOT.APPLICATION."/modules/global/index.php";

//run only for this module/action
if(file_exists(_ROOT.APPLICATION."/modules/global/".$system->module.'.'.$system->action.'.php')){
	require _ROOT.APPLICATION."/modules/global/".$system->module.'.'.$system->action.'.php';
}elseif(file_exists(_ROOT.APPLICATION."/modules/global/".$system->module.'.php')){
	require _ROOT.APPLICATION."/modules/global/".$system->module.'.php';
}


if(file_exists(_ROOT.APPLICATION."/modules/".$system->module.'/classes.php'))
	require _ROOT.APPLICATION."/modules/".$system->module.'/classes.php';
if(file_exists(_ROOT.APPLICATION."/modules/".$system->module.'/functions.php'))
	require _ROOT.APPLICATION."/modules/".$system->module.'/functions.php';
if($system->module) require _ROOT.APPLICATION."/modules/".$system->module.'/index.php';
if($system->action) require _ROOT.APPLICATION."/modules/".$system->module.'/action.'.$system->action.'.php';
if(isset($tpl)) echo $tpl->parse();
$hook->web_footer();
?>