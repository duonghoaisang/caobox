<?php
/**
 * @Name: CaoBox v1.0
 * @author LinhNMT <w2ajax@gmail.com>
 * @link http://code.google.com/p/caobox/
 * @copyright Copyright &copy; 2009 phpbasic
 */
defined('_ROOT') or die(__FILE__);

$cfg = array();
$cfg['driver'] 	= 'mysql';
$cfg['server'] 	= 'localhost';
$cfg['port'] 		= '3306';
$cfg['usr'] 		= 'root';
$cfg['psw'] 		= '123';
$cfg['name'] 		= 'project_saotv';
$cfg['prefix'] 		= 'saotv__';
$cfg['lang'] = 'vn';

$smtp['server'] = 'amail.sofresh.ca';
$smtp['user'] = 'linh.nguyen@sofresh.ca';
$smtp['psw'] = 'amok634tack525';
$smtp['from_email'] = 'orders@myfaceworks.com';
$smtp['from_name'] = 'MyFaceWorks';
$smtp['reply_email'] = 'orders@myfaceworks.com';
$smtp['reply_name'] = 'MyFaceWorks';
$smtp['admin_email'] = 'linh.nguyen@sofresh.ca';
$smtp['email_url'] = 'http://dev.sofresh.ca/myfaceworks/05_site/v02/';


?>