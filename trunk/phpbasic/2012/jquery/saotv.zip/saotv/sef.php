<?php
/**
 * @Name: CaoBox v1.0
 * @author LinhNMT <w2ajax@gmail.com>
 * @link http://code.google.com/p/caobox/
 * @copyright Copyright &copy; 2009 phpbasic
 */
defined('_ROOT') or die(__FILE__);
if($controller->sef){
	$oCfg = new Model;
	$result = $oCfg->db->query("SELECT c.`module`,ln.* FROM ".$oCfg->prefix."module c,".$oCfg->prefix."module_ln ln WHERE c.id = ln.id AND c.active = 1");
	$arrModule = array();
	while($rs = $result->fetch()){
		$_SESSION['module_name'][$rs['module_name']] = $rs;
	}

	$controller->lang = $_SESSION['module_name'][$controller->module]['ln'];
	$controller->module = $_SESSION['module_name'][$controller->module]['module'];
	

}
?>