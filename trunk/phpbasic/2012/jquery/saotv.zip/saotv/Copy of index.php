<?php
//error_reporting(E_ALL & ~E_WARNING & ~E_NOTICE);
define('_ROOT',rtrim(dirname(__FILE__),'/').'/',true);
define('APPLICATION','',true);
define('_CORE',rtrim(dirname(__FILE__),'/').'/',true);
include _ROOT.'bootstrap.php';
/* Controller($rewrite, $htaccess, $multi_lang, $sef) */
$controller = new Controller(true,true,false,true);
//include _ROOT.'sef.php';
$controller->load();
?>