<?php
/**
 * @Name: CaoBox v1.0
 * @author LinhNMT <w2ajax@gmail.com>
 * @link http://code.google.com/p/caobox/
 * @copyright Copyright &copy; 2009 phpbasic
 */
defined('_ROOT') or die(__FILE__);

class GalleryDAO{
	var $db;
	function __construct(){
		global $db;
		$this->db = $db;
	}
	

	function view($page,$pageid,$orderby=" order_id,id"){
		return $this->db->query("SELECT * FROM ".$this->prefix."gallery WHERE page='".addslashes($page)."' AND pageid=".intval($pageid)." ORDER BY $orderby");
	}
}

?>