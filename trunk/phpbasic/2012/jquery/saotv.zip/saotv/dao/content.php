<?php
/**
 * @Name: CaoBox v1.0
 * @author LinhNMT <w2ajax@gmail.com>
 * @link http://code.google.com/p/caobox/
 * @copyright Copyright &copy; 2009 phpbasic
 */
defined('_ROOT') or die(__FILE__);

class ContentDao{
	var $db;
	function __construct(){
		global $db;
		$this->db = $db;
	}
	
	function view($type = -1,$cond = 1,$start = 0,$limit = 0,$orderby = "order_id"){
		$cond_type = 1;
		if(is_array($type)) $cond_type = " c.type IN (".implode(',',$type).")"; 
		elseif($type>=0) $cond_type = " c.type = ".intval($type);
		return $this->db->query("SELECT c.*,ln.* FROM ".$this->prefix."content c,".$this->prefix."content_ln ln WHERE c.active = 1 AND $cond_type AND c.id = ln.id AND ln.ln = '".$this->lang."' AND $cond ORDER BY $orderby".($limit?" LIMIT $start,$limit":""));
	}	

	function get($id  = 0){
		$result =  $this->db->query("SELECT c.*,ln.* FROM ".$this->prefix."content c,".$this->prefix."content_ln ln WHERE c.active = 1  AND c.id = ln.id AND ln.ln = '".$this->lang."' AND c.id = ".intval($id));
		return $result->fetch();
	}	
	
	
	

}

?>