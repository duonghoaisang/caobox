<?php
/**
 * @Name: CaoBox v1.0
 * @author LinhNMT <w2ajax@gmail.com>
 * @link http://code.google.com/p/caobox/
 * @copyright Copyright &copy; 2009 phpbasic
 */
defined('_ROOT') or die(__FILE__);

class CommentDAO{
	var $db;
	function __construct(){
		global $db;
		$this->db = $db;
	}
	
	function view($page,$pageid){
		return $this->db->query("SELECT c.*,m.username FROM ".$this->prefix."comment c
		WHERE c.page='$page' AND c.pageid=".intval($pageid)." ORDER BY `timestamp` DESC");
	}


	function language($cond = 1){
		return $this->db->query("SELECT * FROM ".$this->prefix."language WHERE $cond ORDER BY order_id");
	}

}

?>