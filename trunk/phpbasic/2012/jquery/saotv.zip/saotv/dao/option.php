<?php
/**
 * @Name: CaoBox v1.0
 * @author LinhNMT <w2ajax@gmail.com>
 * @link http://code.google.com/p/caobox/
 * @copyright Copyright &copy; 2009 phpbasic
 */
defined('_ROOT') or die(__FILE__);

class OptionDAO{
	var $db;
	function __construct(){
		global $db;
		$this->db = $db;
	}
	
	
	function get($id=0){
		return $this->db->query("SELECT c.*,ln.* FROM ".$this->prefix."html c, ".$this->prefix."html_ln ln WHERE c.id = ln.id AND ln.ln = '".$this->lang."' AND c.id = ".intval($id));
	}
	
	function view(){
	
	}

}

?>