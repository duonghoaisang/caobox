<?php
/**
 * @Name: CaoBox v1.0
 * @author LinhNMT <w2ajax@gmail.com>
 * @link http://code.google.com/p/caobox/
 * @copyright Copyright &copy; 2009 phpbasic
 */
 
defined('_ROOT') or die(__FILE__);

if($_POST){
	$refresh = '?'.http_build_query($_GET);
	if($_POST['content_action']=='delete'){
		if($_POST['pro']) foreach($_POST['pro'] as $id) $oClass->delete($id);
		$hook->redirect($refresh);
	}elseif($_POST['content_action'] == 'top'){
		if($_POST['pro']) foreach($_POST['pro'] as $id) $oClass->top($id,1);
		$hook->redirect($refresh);
	
	}elseif($_POST['content_action'] == 'intop'){
		if($_POST['pro']) foreach($_POST['pro'] as $id) $oClass->top($id,0);
		$hook->redirect($refresh);
	
	}elseif($_POST['content_action'] == 'active'){
		if($_POST['pro']) foreach($_POST['pro'] as $id) $oClass->active($id,1);
		$hook->redirect($refresh);
	
	}elseif($_POST['content_action'] == 'inactive'){
		if($_POST['pro']) foreach($_POST['pro'] as $id) $oClass->active($id,0);
		$hook->redirect($refresh);
	
	}elseif($_POST['content_action']=='move'){
		$current_catid = $request['parentid'];
		$tpl->setfile(array(
			'body'=>'content.move.tpl',
		));
		$tpl->assign(array(
			'products'=>implode(',',$_POST['pro']),
			'form_action'=>'?mod=content&act=move&parentid='.$request['parentid'].'&type='.$request['type'],
		));
		$tree = $oCategory->tree($request['type'],0,'&nbsp;',1);
		foreach($tree as $rs){
			$rs['prefix'] = $rs['prefix'].'|&mdash;';
			$rs['selected'] = $rs['id']==$current_catid?'selected':'';
			$tpl->assign($rs,'category');
		}
		$breadcrumb->assign("","Move to category");
	}else{
		$hook->redirect($refresh);
	}

}else{

	$tpl->setfile(array(
		'body'=>'content.tpl',
	));
	
	
	$cat = $oCategory->view($request['type'],$request['parentid'],$request['q'],$cfg_type['catsorted_by'],$cfg_type['catsorted_order']);
	while($rs = $cat->fetch()){
		$rs = $hook->format($rs);
		if($cfg_type['nodelcat_ids'] && in_array($rs['id'],explode(',',$cfg_type['nodelcat_ids']))) $delcat = 0;
		if($delcat) $rs['delcat'] = ' style="display: inline;"';
		$tpl->assign($rs,'category');
	}
	
	$start = LIMIT * intval($_GET['page']);
	$cond = 1;
	$pro = $oClass->view($request['type'],$request['parentid'],$request['q'],$cond);
	$total = $pro->num_rows();
	
	$url = 'mod='.$system->module.'&parentid='.intval($_GET['parentid']).'&type='.intval($_GET['type']);
	$dp = new paging($url,$total,LIMIT);
	$request['divpage'] = $dp->simple();

	$pro = $oClass->view($request['type'],$request['parentid'],$request['q'],$cond,$start,LIMIT,$cfg_type['sorted_by'],$cfg_type['sorted_order']);
	while($rs = $pro->fetch()){
		$rs = $hook->format($rs);
		if($cfg_type['thumb_field'] && $rs[$cfg_type['thumb_field']]){
			if($cfg_type['thumb_field']=='date') $rs['thumb_field'] ='<em class="red">['.date(DATE_FORMAT,strtotime($rs['date'])).']</em>&nbsp;';
			else $rs['thumb_field'] = '<a href="'._UPLOAD.$rs[$cfg_type['thumb_field']].'" class="mb" style="margin-right: 4px;"><img align="left" src="'._UPLOAD.$rs[$cfg_type['thumb_field']].'" width="40" height="40" /></a> ';
		}
		$rs['list_field'] = $rs[$cfg_type['list_field']]?$rs[$cfg_type['list_field']]:$rs['name'];
		if($cfg_type['nodel_ids'] && in_array($rs['id'],explode(',',$cfg_type['nodel_ids']))) $delrecord = 0;
		$rs['delrecord'] = $delrecord?' style="display: inline;"':'';
		$rs['featureon'] = $rs['featuredon']?'edit':'add';
		$tpl->assign($rs,'product');
	}
	
	if($request['q']){
		$req = $_GET;
		unset($req['q'],$req['cmd']);
		$request['search_result'] = ' <a href="?'.http_build_query($req).'">Clear search</a>';
		
	}else{
		$request['q'] = 'Enter a keyword';
	}
	if(!$total) $request['display_checkall'] = 'display: none;';
	
	$breadcrumb->reset();
	$menu = explode('.',$_SESSION['cms_menu']);
	$breadcrumb->assign("",$MenuName[$menu[0]]);
	$level = $MenuLink[$menu[0]][$menu[1]];
	$breadcrumb->assign($level['link'],$level['name']);
	
	$action = array();
	if($show_actions) foreach($show_actions as $act){
		$tmp = explode(':',$act);
		$action['action_'.$tmp[0]] = 'style="display: '.($tmp[1]?$tmp[1]:'inline').';"';
	}
	$tpl->assign($action);
	if(in_array('move',$show_actions)) $tpl->box('move');
	if(in_array('top:table-cell',$show_actions)) $tpl->box('top');
}
$request['breadcrumb'] = $breadcrumb->parse();
$tpl->assign($request);
$action = array();

?>