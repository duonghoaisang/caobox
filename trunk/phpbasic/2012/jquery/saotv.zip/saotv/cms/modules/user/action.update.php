<?php
/**
 * @Name: CaoBox v1.0
 * @author LinhNMT <w2ajax@gmail.com>
 * @link http://code.google.com/p/caobox/
 * @copyright Copyright &copy; 2009 phpbasic
 */
defined('_ROOT') or die(__FILE__);

$userid = $_SESSION['admin_login']['id'];
if($access=='ALL' && $request['id']) $userid = $request['id'];

if($_POST){
	
	
	$arr = array(
		'fullname'=>$_POST['fullname'],
		'username'=>$_POST['username'],
		'skin'=>$_POST['skin'],
	);
	
	if($do=='new' && $access == 'ALL'){
		$arr['permission'] = 'ALL';
		$lastid = $oClass->insert($arr);
	}else{
		$oClass->update($userid,$arr);
		if($userid == $_SESSION['admin_login']['id']) $_SESSION['admin_login']['fullname'] = $arr['fullname'];
	}

	
	
	
	// refresh
	
	$query_string = $_SERVER['QUERY_STRING'];
	parse_str($query_string,$result);
	unset($result['mod'],$result['act'],$result['id'],$result['do']);
	if($do=='') $result['msg'] = 'Data has been updated. You must logout and login again to see what you updated!';
	$result['mod'] = $access=='ALL'?'user':'home';
	
	$hook->redirect('?'.http_build_query($result));
}


$tpl->setfile(array(
	'body'=>'user.update.tpl',
));


if($do=='new'){
	$cat_ln = array();
	$breadcrumb->assign("","New");
	$c_skin  = 'style.css';
}else{
	$cat = $oClass->get($userid);
	$u = $cat->fetch();
	$c_skin = $u['skin'];
	$tpl->assign($u);
	$breadcrumb->assign("","Edit",$request['bread']);
	if($userid == $_SESSION['admin_login']['id']){
		$breadcrumb->reset();
		$breadcrumb->assign('','CMS');
		$breadcrumb->assign('','Profile');
	}
}
$skins = skins($tpl->tpl_dir);
foreach($skins as $arr){
	$rs = array();
	$rs['value'] = $arr[1];
	$rs['selected'] = $arr[1] == $c_skin?'selected':'';
	$rs['name'] = $arr[0];
	$tpl->assign($rs,'skin');
}
$request['breadcrumb'] = $breadcrumb->parse();

$tpl->assign($request);




?>