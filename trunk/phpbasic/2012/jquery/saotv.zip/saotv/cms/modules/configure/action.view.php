<?php
/**
 * @Name: CaoBox v1.0
 * @author LinhNMT <w2ajax@gmail.com>
 * @link http://code.google.com/p/caobox/
 * @copyright Copyright &copy; 2009 phpbasic
 */
defined('_ROOT') or die(__FILE__);
if($_POST){
	unset($_POST['Submit']);
	$oClass->update($_POST);
	$hook->redirect('?mod=configure');
}
extract($_GET);
$request = $_GET;
$request['type'] = intval($type);
$request['parentid'] = intval($parentid);

$tpl->setfile(array(
	'body'=>'configure.tpl',
));

$cat = $oConfigure->getMod("`module` = 'content'");
while($rs = $cat->fetch()){
	$rs['attr'] = $rs['is_attribute']?'<em>(Attr)</em> ':'';
	$tpl->assign($rs,'cfg_module');
}
$cat = $oConfigure->getMod("`module` = 'html'");
while($rs = $cat->fetch()){
	$result = $oClass->check_html($rs['typeid']);
	$rs['plus'] = $result->num_rows()?'':' <a href="#" onclick="newHTMLCfg('.$rs['typeid'].');return false;"><img src="template/'.$cfg['template'].'/images/plus.jpg" border="0" /></a>';
	$tpl->assign($rs,'cfg_html');
}

$cat = $oConfigure->getMod("`module` = 'options'");
while($rs = $cat->fetch()){
	$tpl->assign($rs,'options');
}

$breadcrumb->reset();
$menu = explode('.',$_SESSION['cms_menu']);
$breadcrumb->assign("",$MenuName[$menu[0]]);
$level = $MenuLink[$menu[0]][$menu[1]];
$breadcrumb->assign($level['link'],$level['name']);


$request['breadcrumb'] = $breadcrumb->parse();
$result = $oConfigure->get();
while($rs = $result->fetch()){
	$rs = $hook->format($rs);
	$tpl->assign($rs,'cfg_common');
}

// configure common values


$tpl->assign($request);

?>