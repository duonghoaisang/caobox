<?php
/**
 * @Name: CaoBox v1.0
 * @author LinhNMT <w2ajax@gmail.com>
 * @link http://code.google.com/p/caobox/
 * @copyright Copyright &copy; 2009 phpbasic
 */
 
defined('_ROOT') or die(__FILE__);
if($_GET['do']=='new'){
	$result = $oClass->max_module($request['module']);
	$data = $result->fetch();
	$oClass->insert_module($request['module'],intval($data['maxid'])+1,$request['name']);
	$hook->redirect('?mod=configure');
}

if($_GET['do']=='newhtml'){
	$oClass->insert_html($request['typeid']);
	$hook->redirect('?mod=configure');
}

if($_GET['do']=='copy'){
	$result = $oClass->get_module($request['module'],$request['from']);
	$data = $result->fetch();
	$oClass->update_module($request['module'],$request['typeid'],array('data'=>$data['data']));
	$hook->redirect('?mod=configure');
}

if($_POST){
	// update main	
	$name = $_POST['name'];
	$content = $_POST['content'];
	unset($_POST['name'],$_POST['Submit'],$_POST['content']);
	$arr = array(
		'name'=>$name,
		'content'=>$content,
		'data'=>serialize($_POST)
	);
	
	
	$oClass->update_module($request['module'],$request['typeid'],$arr);


	// refresh
	
	$query_string = $_SERVER['QUERY_STRING'];
	parse_str($query_string,$result);
	unset($result['act'],$result['module'],$result['typeid'],$result['page_or_id']);
	$hook->redirect('?'.http_build_query($result));
}


$tpl->setfile(array(
	'body'=>'configure.module.'.$request['module'].'.tpl',
));

$result = $oClass->get_module($request['module'],$request['typeid'],$request['page_or_id']);
$cfg = $result->fetch();
$data = array();
$request['name'] = $cfg['name'];
$request['content'] = $cfg['content'];
if($cfg['data']) $data = unserialize($cfg['data']);

$arrCfg = array();
//action
if($data['act']) foreach($data['act'] as $v){
	$tmp = explode(':',$v);
	$arrCfg[$tmp[0].'_checked'] = 'checked';
}

if($request['module'] == 'content'){
	$cat = $oConfigure->getMod("`module` = 'options'");
	while($rs = $cat->fetch()){
		$rs['checked'] = is_array($data['options'])&&in_array($rs['typeid'],$data['options'])?'checked':'';
		$rs['selected_'.$data['options_type'][$rs['typeid']]] = 'selected';
		$tpl->assign($rs,'options');
	}
}

//show fields
$arrCfg['show_fields'] = $data['show_fields'];
$arrCfg['list_field'] = $data['list_field'];
$arrCfg['gallery_fields'] = $data['gallery_fields'];
$arrCfg['nlevel'] = intval($data['nlevel']);
$arrCfg['category_fields'] = $data['category_fields'];
$arrCfg['category_required'] = $data['category_required'];
$arrCfg['required_fields'] = $data['required_fields'];
$arrCfg['thumb_field'] = $data['thumb_field'];
$arrCfg['web_title'] = $data['web_title'];
$arrCfg['meta_keywords'] = $data['meta_keywords'];
$arrCfg['meta_desc'] = $data['meta_desc'];
$arrCfg['noproduct_level'] = $data['noproduct_level'];
$arrCfg['noproduct_cat'] = $data['noproduct_cat'];
$arrCfg['nosubcat_level'] = $data['nosubcat_level'];
$arrCfg['nosubcat_cat'] = $data['nosubcat_cat'];
$arrCfg['nodelcat_ids'] = $data['nodelcat_ids'];
$arrCfg['nodel_ids'] = $data['nodel_ids'];
$arrCfg['nodelcat_level_checked'] = $data['nodelcat_level']?'checked':'';
$arrCfg['nodelcat_cat_checked'] = $data['nodelcat_cat']?'checked':'';

//
$arrCfg['main_icon_chose'] = $data['main_icon']['chose']?'checked':'';
$arrCfg['main_icon_w'] = intval($data['main_icon']['w']);
$arrCfg['main_icon_h'] = intval($data['main_icon']['h']);

$arrCfg['main_img_chose'] = $data['main_img']['chose']?'checked':'';
$arrCfg['main_img_w'] = intval($data['main_img']['w']);
$arrCfg['main_img_h'] = intval($data['main_img']['h']);

$arrCfg['main_thumb_chose'] = $data['main_thumb']['chose']?'checked':'';
$arrCfg['main_thumb_w'] = intval($data['main_thumb']['w']);
$arrCfg['main_thumb_h'] = intval($data['main_thumb']['h']);

$arrCfg['ln_main_icon_chose'] = $data['ln_main_icon']['chose']?'checked':'';
$arrCfg['ln_main_icon_w'] = intval($data['ln_main_icon']['w']);
$arrCfg['ln_main_icon_h'] = intval($data['ln_main_icon']['h']);

$arrCfg['ln_main_img_chose'] = $data['ln_main_img']['chose']?'checked':'';
$arrCfg['ln_main_img_w'] = intval($data['ln_main_img']['w']);
$arrCfg['ln_main_img_h'] = intval($data['ln_main_img']['h']);

$arrCfg['ln_main_thumb_chose'] = $data['ln_main_thumb']['chose']?'checked':'';
$arrCfg['ln_main_thumb_w'] = intval($data['ln_main_thumb']['w']);
$arrCfg['ln_main_thumb_h'] = intval($data['ln_main_thumb']['h']);

$arrCfg['gallery_icon_chose'] = $data['gallery_icon']['chose']?'checked':'';
$arrCfg['gallery_icon_w'] = intval($data['gallery_icon']['w']);
$arrCfg['gallery_icon_h'] = intval($data['gallery_icon']['h']);

$arrCfg['gallery_img_chose'] = $data['gallery_img']['chose']?'checked':'';
$arrCfg['gallery_img_w'] = intval($data['gallery_img']['w']);
$arrCfg['gallery_img_h'] = intval($data['gallery_img']['h']);

$arrCfg['gallery_thumb_chose'] = $data['gallery_thumb']['chose']?'checked':'';
$arrCfg['gallery_thumb_w'] = intval($data['gallery_thumb']['w']);
$arrCfg['gallery_thumb_h'] = intval($data['gallery_thumb']['h']);

$arrCfg['catimg_icon_chose'] = $data['catimg_icon']['chose']?'checked':'';
$arrCfg['catimg_icon_w'] = intval($data['catimg_icon']['w']);
$arrCfg['catimg_icon_h'] = intval($data['catimg_icon']['h']);

$arrCfg['catimg_icon2_chose'] = $data['catimg_icon2']['chose']?'checked':'';
$arrCfg['catimg_icon2_w'] = intval($data['catimg_icon2']['w']);
$arrCfg['catimg_icon2_h'] = intval($data['catimg_icon2']['h']);

$arrCfg['catimg_img_chose'] = $data['catimg_img']['chose']?'checked':'';
$arrCfg['catimg_img_w'] = intval($data['catimg_img']['w']);
$arrCfg['catimg_img_h'] = intval($data['catimg_img']['h']);

$arrCfg['catimg_thumb_chose'] = $data['catimg_thumb']['chose']?'checked':'';
$arrCfg['catimg_thumb_w'] = intval($data['catimg_thumb']['w']);
$arrCfg['catimg_thumb_h'] = intval($data['catimg_thumb']['h']);

$arrCfg['ln_catimg_icon_chose'] = $data['ln_catimg_icon']['chose']?'checked':'';
$arrCfg['ln_catimg_icon_w'] = intval($data['ln_catimg_icon']['w']);
$arrCfg['ln_catimg_icon_h'] = intval($data['ln_catimg_icon']['h']);

$arrCfg['ln_catimg_icon2_chose'] = $data['ln_catimg_icon2']['chose']?'checked':'';
$arrCfg['ln_catimg_icon2_w'] = intval($data['ln_catimg_icon2']['w']);
$arrCfg['ln_catimg_icon2_h'] = intval($data['ln_catimg_icon2']['h']);

$arrCfg['ln_catimg_img_chose'] = $data['ln_catimg_img']['chose']?'checked':'';
$arrCfg['ln_catimg_img_w'] = intval($data['ln_catimg_img']['w']);
$arrCfg['ln_catimg_img_h'] = intval($data['ln_catimg_img']['h']);

$arrCfg['ln_catimg_thumb_chose'] = $data['ln_catimg_thumb']['chose']?'checked':'';
$arrCfg['ln_catimg_thumb_w'] = intval($data['ln_catimg_thumb']['w']);
$arrCfg['ln_catimg_thumb_h'] = intval($data['ln_catimg_thumb']['h']);
$arrCfg['sorted_order_'.$data['sorted_order']] = 'selected';
$arrCfg['catsorted_order_'.$data['catsorted_order']] = 'selected';
$arrCfg['selected_languages_'.$data['languages']] = 'selected';

$tpl->assign($arrCfg);
$request['display_update'] = 'style="display: block;"';
$breadcrumb->assign("","Edit configure type");



//$breadcrumb->reset();

//$breadcrumb->assign("./?mod=product","Manage Products");

$request['breadcrumb'] = $breadcrumb->parse();
$tpl->assign($request);

$sorted_by = array();
$rs = array('value'=>'c.`timestamp`','name'=>'Timestamp');
$tpl->assign($rs,'sorted_by');
if($data['show_fields']){
	$tmp = explode(',',$data['show_fields']);
	for($i=0;$i<count($tmp);$i++){
		$rs = array('value'=>'ln.`'.$tmp[$i].'`','name'=>ucfirst($tmp[$i]));
		$rs['selected'] = 'ln.`'.$tmp[$i].'`' == $data['sorted_by'] ?'selected':'';
		$tpl->assign($rs,'sorted_by');
	}
}

$catsorted_by = array();
$rs = array('value'=>'cat.`timestamp`','name'=>'Timestamp');
$tpl->assign($rs,'catsorted_by');
if($data['category_fields']){
	$tmp = explode(',',$data['category_fields']);
	for($i=0;$i<count($tmp);$i++){
		$rs = array('value'=>'ln.`'.$tmp[$i].'`','name'=>ucfirst($tmp[$i]));
		$rs['selected'] = 'ln.`'.$tmp[$i].'`' == $data['catsorted_by'] ?'selected':'';
		$tpl->assign($rs,'catsorted_by');
	}
}


?>