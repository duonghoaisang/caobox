<?php
/**
 * @Name: CaoBox v1.0
 * @author LinhNMT <w2ajax@gmail.com>
 * @link http://code.google.com/p/caobox/
 * @copyright Copyright &copy; 2009 phpbasic
 */
defined('_ROOT') or die(__FILE__);

$tpl->setfile(array(
	'body'=>'home.tpl',
));

$email = new Email('linh.nguyen@sofresh.ca','Test subject','contact.tpl');
for($i=0;$i<5;$i++){
	$email->assign(array('id'=>$i),'email_list');
}

//$email->send();

/*$fskin = $tpl->tpl_dir.'skins.txt';
if(file_exists($fskin)){
	$handle = fopen($fskin, "r");
	while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
		print_r($data);
	}
}
*/


?>