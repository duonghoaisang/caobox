<?php
/**
 * @Name: CaoBox v1.0
 * @author LinhNMT <w2ajax@gmail.com>
 * @link http://code.google.com/p/caobox/
 * @copyright Copyright &copy; 2009 phpbasic
 */
defined('_ROOT') or die(__FILE__);
$request = $_GET;
$request['type'] = intval($request['type']);
$request['parentid'] = intval($request['parentid']);
if(!$_SESSION['cms_menu']) $_SESSION['cms_menu'] = '0.0';
if($_GET['menu']){
	$_SESSION['cms_menu'] = $request['menu'];
}
$menu = explode('.',$_SESSION['cms_menu']);

//unset($_SESSION);
if($GLOBALS['controller']->module=='user' && $GLOBALS['controller']->action=='login'){
	if(isset($_SESSION['admin_login'])) header('location: ./');
}else{
	if(!isset($_SESSION['admin_login'])) header('location: ./?mod=user&act=login');
}

/* --------------------- LEFT MENU ----------------------------*/

$image_exts = array('.jpg','.jpeg','.gif','.png');

$tpl = new View('template/'.$cfg['template'],$languages); 
//Load main template
$tpl->setfile(array(
	'main'=>'master.tpl',
));
$tpl->assign(array(
	'module'=>$system->module,
	'action'=>$system->action,
	'language'=>$system->lang,
	'page'=>$system->page,
	'_UPLOAD'=>_UPLOAD,
	'web_client'=>$cfg['client'],
	'system_year'=>date('Y'),
));
$login_user = $_SESSION['admin_login'];
if(!$login_user['skin']) $login_user['skin'] = 'style.css';
$tpl->merge($login_user,'login_user');

$result = $oConfigure->get("`code` = 'language_tab'");
$language_tab = $result->fetch();
if($language_tab['value'] == 'tab'){
	$tpl->box('language_tab');
}

if($_SESSION['admin_login']['permission'] == 'ALL') $access = 'ALL';
else $access = unserialize($_SESSION['admin_login']['permission']);

$user_permission = $access['action']?$access['action']:array();
$ucp = array();
if(!$user_permission['new']) $ucp['new'] = '_d';
if(!$user_permission['edit']) $ucp['edit'] = '_d';
if(!$user_permission['delete']) $ucp['delete'] = '_d';
$tpl->merge($ucp,'ucp');
$tpl->merge($user_permission,'access');


if($access!='ALL') array_pop($MenuName);
for($i=0;$i<count($MenuName);$i++) if($access=='ALL' || $access['act'][$i]){
	$links = '';
	foreach($MenuLink[$i] as $j=>$arr) if($access=='ALL' || $access['act'][$i][$j]){
		$links .= '<a href="'.$arr['link'].'&menu='.$i.'.'.$j.'" '.($_SESSION['cms_menu']==$i.'.'.$j?'class="active"':'').'>'.($arr['icon']?'<img src="template/'.$cfg['template'].'/'.$arr['icon'].'" align="absmiddle" /> ':'').$arr['name'].'</a>';
	}
	$tpl->assign(array(
		'name'=>$MenuName[$i],
		'links'=>$links,
		'firslink'=>$MenuLink[$i][0]['link'].'&menu='.$i.'.0',
	),'leftmenu');
}

$tpl->merge($languages,'lang');
?>