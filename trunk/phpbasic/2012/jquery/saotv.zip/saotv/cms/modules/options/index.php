<?php
/**
 * @Name: CaoBox v1.0
 * @author LinhNMT <w2ajax@gmail.com>
 * @link http://code.google.com/p/caobox/
 * @copyright Copyright &copy; 2009 phpbasic
 */
defined('_ROOT') or die(__FILE__);

$oClass = new ClassModel;
$breadcrumb = new breadcrumb;
$request['query_string'] = '?'.$_SERVER['QUERY_STRING'];
$url = $_GET;
unset($url['act']);
$request['http_referer'] = '?'.http_build_query($url);
$table_row = ie()?'block':'table-row';



$cfg_type = array();
if($request['type']){
	$result = $oConfigure->getMod(" `module`='".$system->module."' AND typeid=".intval($request['type']));
	$tmp = $result->fetch();
	$request['module_description'] = nl2br($tmp['content']);
	if($tmp['data']) $cfg_type = unserialize($tmp['data']);
}	
//
$show_actions = $cfg_type['act']?$cfg_type['act']:array();


$show_fields = $cfg_type['show_fields']?explode(',',$cfg_type['show_fields']):array();

if(in_array('image',$show_actions)&&$cfg_type['main_icon']['chose']) $show_fields[] = 'icon';
if(in_array('image',$show_actions)&&$cfg_type['main_img']['chose']) $show_fields[] = 'image';
if(in_array('ln_image',$show_actions)&&$cfg_type['ln_main_icon']['chose']) $show_fields[] = 'ln_icon';
if(in_array('ln_image',$show_actions)&&$cfg_type['ln_main_img']['chose']) $show_fields[] = 'ln_image';
if(in_array('gallery',$show_actions)) $show_fields[] = 'gallery';

if($cfg_type['gallery_fields']){
	$tmp = explode(',',$cfg_type['gallery_fields']);
	if(in_array('gallery',$cfg_type['act']) && $cfg_type['gallery_icon']['chose']) $tmp[] = 'icon';
	foreach($tmp as $v) $show_fields[] = 'gallery_'.$v.':inline';
}


?>