<?php
/**
 * @Name: CaoBox v1.0
 * @author LinhNMT <w2ajax@gmail.com>
 * @link http://code.google.com/p/caobox/
 * @copyright Copyright &copy; 2009 phpbasic
 */
error_reporting(E_ALL & ~E_WARNING & ~E_NOTICE);
define('_ROOT',rtrim(dirname(dirname(__FILE__)),'/').'/',true);
define('_CORE',_ROOT,true);
define('APPLICATION','cms',true);
include _CORE.'bootstrap.php';
//Controller 
	// argurment 1:  rewrite url ?
	// argument 2:  use mod rewrite ?
	// argument 3: multi language 
$controller = new Controller(false,false,false);
$controller->load();
?>