<?php
/**
 * @Name: CaoBox v1.0
 * @author LinhNMT <w2ajax@gmail.com>
 * @link http://code.google.com/p/caobox/
 * @copyright Copyright &copy; 2009 phpbasic
 */
defined('_ROOT') or die(__FILE__);

$languages = array();
$languages['data_updated'] = 'Data has been updated!';
$languages['invalid_icon_ext'] = 'Invalid icon extension';
$languages['invalid_image_ext'] = 'Invalid image extension';
$languages['user_no_access'] = 'Your account have no access to do this action.';

?>