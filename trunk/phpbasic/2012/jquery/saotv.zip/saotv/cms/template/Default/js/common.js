$(document).ready(function(){
	// Left Menu
	$('#left .submenu h2').toggle(function(){
		$(this).addClass('down');
		$(this).parent().find('a').animate({
			height: 'toggle'
		},500);							   
	},function(){
		$(this).removeClass('down')
		$(this).parent().find('a').animate({
			height: 'toggle'
		},500);	
	})
	
	$('table.list tr').hover(function(){
		this.bgColor = '#eeeecc';
	},function(){
		this.bgColor = '#ffffff';
	});
	
	$('a.mb').divbox({path: '../plugins/divbox/players/'});
})


function checkAll(selects,obj){
	var st = obj.checked;
	$(selects+ ' input[name="pro\\[\\]"]').each(function(){
		this.checked = st;
	});
}

// function deleteConfirm 
function deleteConfirm(o,msg){
	if(window.confirm(msg?msg:'Do you really want to delete the selected row(s) ?')){
		if(access_delete) location.href=o.href+'&c=1';
		else{alert('You have no access to do this action.');return false;}
	}
	return false;
}


function add_gallery(selector,is_gallery_name,is_gallery_icon){
	var len = $(selector+ ' input[type="file"]').length+1;	
	$(selector).append('<p><span class="hide" '+(is_gallery_name?'style="display: inline;"':'')+'>Title <input name="name_gallery'+len+'" type="text" value="" title="" /><br /></span><span class="hide" '+(is_gallery_icon?'style="display: inline;"':'')+'>Icon <input type="file" name="icon_gallery'+len+'" class="no_width" /> </span>Image <input type="file" name="image_gallery'+len+'" class="no_width" /></p>');
}

function  deleteGallery(selects,type){
	if(window.confirm('Are you really  want to delete selected image(s)?')){
		if(access_delete){
			$(selects+' input[name="del_gallery\\[\\]"]').each(function(){
				var id = this.value;
				if(this.checked) $.post('?mod=gallery&act=delete&p=content&c=1&echo=1&type='+type+'&id='+id,{},function(data){
					if(data=='1') $(selects+ ' #'+id).remove();
				});
			});
		}else{
			alert('You have no access to do this action');	
		}
	}
}


function newConfigure(mod){
	var name = window.prompt('Input name: ');
	if(name) location.href='?mod=configure&act=module&module='+mod+'&name='+name+'&do=new';
}

function copyConfigure(mod,typeid){
	var from = window.prompt('Input Module Id');
	if(from) location.href='?mod=configure&act=module&module='+mod+'&typeid='+typeid+'&from='+from+'&do=copy';
}

function newHTMLCfg(typeid){
	var c = window.confirm('Are you sure?');
	if(c) location.href='?mod=configure&act=module&typeid='+typeid+'&do=newhtml';
}

function data_attr(sel){
	$('#attr_data,#main_data').hide();
	$(sel).show();
}

function checkSubmitAction(doc){
	if(doc.content_action.value==''){ alert('Please chose the action!');doc.content_action.focus();return false;}
	if(doc.content_action.value == 'delete'){
		if(window.confirm('Are you sure you want to delete  selected items ?')){
			if(access_delete) return true;
			alert('You have no access to do this action');
			return false;
		}
	}
	return true;
}

function str2sef(str,sel){
	str = str.toLowerCase();
	str = str.replace(/\-/ig,' ');
	str = str.replace(/\s+/ig,'-');
	$(sel).val(str);	
}

function showLangTab(ln,o){
	$('.form p.language_tab a').removeClass('active');
	$(o).addClass('active');
	$('table.table_list tbody.tab_language').addClass('hide');
	$('table.table_list tbody#tab_'+ln).removeClass('hide');
}