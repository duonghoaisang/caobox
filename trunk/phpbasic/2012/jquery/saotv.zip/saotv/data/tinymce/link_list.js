// This list may be created by a server logic page PHP/ASP/ASPX/JSP in some backend system.
// There links will be displayed as a dropdown in all link dialogs if the "external_link_list_url"
// option is defined in TinyMCE init.

var tinyMCELinkList = new Array(
	["phpbasic.com", "http://phpbasic.com"],
	["google.com", "http://www.google.com.vn"]
);
