var tinyMCEImageList = new Array(
	["Logo 1", "../data/tinymce/images/logo.jpg"],
	["Logo 2 Over", "../data/tinymce/images/logo_over.jpg"]
);
